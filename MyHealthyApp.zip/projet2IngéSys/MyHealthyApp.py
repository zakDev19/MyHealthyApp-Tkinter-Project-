from tkinter import *
from tkinter import messagebox
import tkinter as tk
import math


# config

categories = ["Entrée", "Plat", "Dessert", "Boisson"]
couleurs = {
    "Entrée": "#6ab04c",
    "Plat": "#f0932b",
    "Dessert": "#eb4d4b",
    "Boisson": "#686de0"
}
quantites = {cat: 0 for cat in categories}
canvas = {}
canvas_barres = {}
labels = {}

BG = "#f5f5f5"
BTN = "#4a90e2"

# fonts 
FONT_TITLE = ("Segoe UI", 14, "bold")
FONT_SUBTITLE = ("Segoe UI", 11, "bold")
FONT_TEXT = ("Segoe UI", 10)
FONT_SMALL = ("Segoe UI", 9)


# fenêtre

root = Tk()
root.title("MyHealthyApp")
root.geometry('950x530')
root.configure(bg=BG)


root.grid_rowconfigure(0, weight=1)
root.grid_columnconfigure(0, weight=1)

# variables tkinter
nb_var = StringVar()
prenom_var = StringVar()
nom_var = StringVar()

# font globale 
root.option_add("*Font", FONT_TEXT)

error_label = tk.Label(root, text="", fg="red", bg=BG)
error_label.grid(row=1, column=0)

error_label2 = tk.Label(root, text="", fg="red", bg=BG)
error_label2.grid(row=4, column=0)

participants = []


# fonctions

def valider_nb():
    if not nb_var.get().isdigit():
        error_label.config(text="Entrez un nombre valide !")
        return

    global max_cat

    nb = int(nb_var.get())
    max_cat = math.ceil(nb / 4)

    accueil.grid_remove()
    page_principale.grid(row=0, column=0, padx=10, pady=10)
    affichage_circulaire()
    affichage_barres()


def ajouter():
    if len(participants) >= int(nb_var.get()):
        error_label2.config(text="Tous les participants sont déjà présents")
        return

    prenom = prenom_var.get()
    nom = nom_var.get()

    selection = listbox_cat.curselection()
    if not selection:
        messagebox.showwarning("Erreur", "Choisissez une catégorie")
        return

    cat = listbox_cat.get(selection[0])

    error_label2.config(text="")

    if prenom == "" or nom == "":
        messagebox.showwarning("Erreur", "Champs vides")
        return

    if quantites[cat] >= max_cat:
        messagebox.showwarning("Erreur", "Catégorie pleine")
        return

    if (prenom, nom) in participants:
        error_label2.config(text="Participant déjà présent")
        return

    participants.append((prenom, nom))
    quantites[cat] += 1

    liste.insert(END, f"{prenom} {nom} - {cat}")

    affichage_circulaire()
    affichage_barres()

    prenom_var.set("")
    nom_var.set("")


def affichage_circulaire():
    for cat in categories:
        canvas[cat].delete("all")

        val = quantites[cat]
        angle = (val / max_cat) * 360

        canvas[cat].create_oval(10, 10, 90, 90, outline="#ddd", width=8)

        canvas[cat].create_arc(
            10, 10, 90, 90,
            start=90,
            extent=-angle,
            style="arc",
            width=8,
            outline=couleurs[cat]
        )

        labels[cat].config(text=f"{val} / {max_cat}")


# page accueil

accueil = Frame(root, bg=BG, bd=2, relief="groove")
accueil.grid(row=0, column=0)

Label(
    accueil,
    text="Nombre de participants",
    bg=BG,
    font=FONT_SUBTITLE
).grid(row=0, column=1, pady=10)

entre_un_nb = Entry(accueil, textvariable=nb_var, justify="center", font=FONT_TEXT)
entre_un_nb.grid(row=1, column=1, pady=5)

Button(
    accueil,
    text="Valider",
    bg=BTN,
    fg="white",
    font=FONT_TEXT,
    command=valider_nb
).grid(row=2, column=1, pady=10)


# page principale

page_principale = Frame(root, bg=BG)

# formulaire
formulaire = Frame(page_principale, bg="white", bd=1, relief="solid")
formulaire.grid(row=0, column=0, padx=10, pady=10, sticky="n")

Label(
    formulaire,
    text="Ajouter participant",
    bg="white",
    font=FONT_SUBTITLE
).grid(row=0, column=0, columnspan=2, pady=5)

entre_un_prenom = Entry(formulaire, textvariable=prenom_var, font=FONT_TEXT)
entre_un_prenom.grid(row=1, column=0, padx=5, pady=5)

entre_un_nom = Entry(formulaire, textvariable=nom_var, font=FONT_TEXT)
entre_un_nom.grid(row=1, column=1, padx=5, pady=5)

# catego avec listbox
listbox_cat = Listbox(formulaire, height=4, exportselection=False, font=FONT_TEXT)
for cat in categories:
    listbox_cat.insert(END, cat)

listbox_cat.grid(row=2, column=0, columnspan=2, pady=5)
listbox_cat.selection_set(0)

Button(
    formulaire,
    text="Ajouter",
    bg=BTN,
    fg="white",
    font=FONT_TEXT,
    command=ajouter
).grid(row=3, column=0, columnspan=2, pady=10)


# liste participants
frame_liste = Frame(page_principale, bg="white", bd=1, relief="solid")
frame_liste.grid(row=0, column=1, padx=10, pady=10)

Label(frame_liste, text="Participants", bg="white", font=FONT_SUBTITLE).pack()
Label(frame_liste, text="Prénom    Nom     Aliment", font=FONT_TEXT).pack()

liste = Listbox(frame_liste, width=30, font=FONT_TEXT)
liste.pack(padx=5, pady=5)


# jauges
frame_jauge = Frame(page_principale, bg="white", bd=1, relief="solid")
frame_jauge.grid(row=2, column=0, columnspan=2, pady=10)

for cat in categories:
    frame_cat = Frame(frame_jauge, bg="white")
    frame_cat.pack(side=LEFT, padx=20)

    canvas[cat] = Canvas(frame_cat, width=100, height=100, bg="white", highlightthickness=0)
    canvas[cat].pack()

    labels[cat] = Label(frame_cat, text="0 / 0", bg="white", font=FONT_TEXT)
    labels[cat].pack()


# résumé
message_resume = Label(
    page_principale,
    text="",
    bg="#f5e2ac",
    fg="#a05a00",
    font=FONT_SUBTITLE
)
message_resume.grid(row=3, column=0, columnspan=2, pady=5, sticky="ew")

barres = {}
labels_barres = {}

for cat in categories:
    frame_cat = Frame(frame_jauge, bg="white")
    frame_cat.pack(fill="x", pady=5)

    Label(frame_cat, text=cat, bg="white", width=12, anchor="w", font=FONT_TEXT).pack(side=LEFT)

    canvas_bar = Canvas(frame_cat, width=200, height=10, bg="#eee", highlightthickness=0)
    canvas_bar.pack(side=LEFT, padx=5)

    barres[cat] = canvas_bar
    labels_barres[cat] = Label(frame_cat, text="0%", bg="white", width=6, font=FONT_SMALL)
    labels_barres[cat].pack(side=LEFT)


def maj_resume():
    manques = []

    for cat in categories:
        diff = max_cat - quantites[cat]
        if diff > 0:
            manques.append(f"{diff} {cat.lower()}")

    if manques:
        texte = " ⚫️ Il manque " + " et ".join(manques)
    else:
        texte = "Tout est complet 🎉"

    message_resume.config(text=texte)


def affichage_barres():
    for cat in categories:
        val = quantites[cat]

        ratio = val / max_cat if max_cat > 0 else 0
        largeur = ratio * 200

        barres[cat].delete("all")
        barres[cat].create_rectangle(0, 0, largeur, 10, fill=couleurs[cat], width=0)

        labels_barres[cat].config(text=f"{int(ratio*100)}%")

    maj_resume()


root.mainloop()